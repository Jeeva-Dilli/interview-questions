package com.dev.util;

public class Java7Feat {   
	    public static void main(String[] args){
	        try{    
	            int[] array = new int[10];
	            array[10] = 30/0;    
	        } 
	        catch(Exception e)
	        {
	        	System.out.println(e);
	        }
	      
	        
	        
	     }    
	}  

