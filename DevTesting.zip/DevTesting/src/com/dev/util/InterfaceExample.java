package com.dev.util;

public class InterfaceExample {

}
