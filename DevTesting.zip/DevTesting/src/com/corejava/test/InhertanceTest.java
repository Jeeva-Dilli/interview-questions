package com.corejava.test;

class Btest {
    int a;

    void add() {

    }

    @Override
    public boolean equals(Object o) {
        Btest b = (Btest) o;
        return this.a == b.a;
    }
}

public class InhertanceTest {
    public static void main(String[] args) {
        Btest b = new Btest();
        b.a = 10;
        Btest b1 = new Btest();
        b1.a = 10;

        System.out.println(b == b1);
        System.out.println(b.equals(b1));

    }
}