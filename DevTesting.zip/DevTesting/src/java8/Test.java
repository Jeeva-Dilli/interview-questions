package java8;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
       Integer n[]=new Integer[]{10,20,30};
        Arrays.sort(n);
    }
}
