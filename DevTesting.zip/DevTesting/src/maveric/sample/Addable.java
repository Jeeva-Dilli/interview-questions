//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package maveric.sample;

interface Addable {
    int add(int var1, int var2);
}
